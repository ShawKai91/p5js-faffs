class Arm {

  constructor(x, y, len, angle) {
    this.x = x;
    this.y = y;
    this.angle = angle;
    this.len = len;
  }

  show(vol) {
    push();
    translate(this.x, this.y);
    rotate(this.angle);
    this.branch(this.len, vol);
    pop();
  }

  branch(len, vol) {
    let max = map(vol, 0, 1, 0.2, 5);
    //let angle = random(0.2,0.2+vol*10);
    let angle = random(0.2, max);
    stroke(0);
    strokeWeight(3);
    line(0, 0, 0, -len);
    translate(0, -len);
    if (len > 8) {
      push();
      rotate(angle);
      this.branch(len * 0.67, vol);
      pop();
      push();
      rotate(-angle);
      this.branch(len * 0.67, vol);
      pop();
    }
  }
}






class Snowball {
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.color = 255;
  }

  show(vol) {
    noStroke();
    fill(this.color);
    circle(this.x, this.y, this.r * 2);
  }
}

class Button extends Snowball {
  constructor(x, y, r) {
    let range = r * 0.25;
    x += random(-range, range);
    y += random(-range, range);
    r *= random(0.9, 1.1);
    super(x, y, r);
    this.color = 0;
  }

  show(vol) {
    noStroke();
    fill(this.color);
    let range = vol * 40;
    let x = this.x + random(-range, range);
    let y = this.y + random(-range, range);
    let r = this.r * 2 * (1 + vol * 10);
    
    circle(x, y, r);
  }
}