class Snowpal {
  constructor(r) {
    this.snowballs = [];
    this.r = r;
    let y = height - r;
    let x = width / 2;
    for (let i = 0; i < 3; i++) {
      this.snowballs[i] = new Snowball(x, y, r);
      y -= r;
      r = r * golden;
      y -= r * 0.6;
    }

    this.buttons = [];
    let startY = this.snowballs[1].y;
    let endY = this.snowballs[0].y;
    let num = floor(random(3, 6));
    for (let i = 0; i < num; i++) {
      let y = map(i, 0, num - 1, startY, endY);
      let bx = x;
      let by = y;
      let br = this.r * 0.1; //random(0.09, 0.11);
      this.buttons[i] = new Button(bx, by, br);
    }

    let head = this.snowballs[2];
    let offset = head.r * 0.25;
    let headR = head.r * 0.1;
    let eyeL = new Button(
      head.x - offset,
      head.y - offset,
      headR);
    let eyeR = new Button(
      head.x + offset,
      head.y - offset,
      headR);
    this.buttons.push(eyeL, eyeR);

    this.mouth = [];
    for (let n = 0; n < 8; n++) {
      let angle = map(n, 0, 7, 0.2, PI - 0.2);
      let x = head.x + cos(angle) * offset * 2;
      let y = head.y + sin(angle) * offset * 2;
      this.mouth.push(new Button(x, y, headR * 0.7));
      //this.buttons.push(mouth);
    }

    this.nose = createVector(head.x, head.y - 5);

    let body = this.snowballs[1];
    let lax = body.x - body.r * 0.8;
    let rax = body.x + body.r * 0.8;
    this.leftArm = new Arm(lax, body.y, 50, -PI / 4);
    this.rightArm = new Arm(rax, body.y, 50, PI / 4);

  }

  show(vol) {
    for (let ball of this.snowballs) {
      ball.show();
    }
    for (let button of this.buttons) {
      button.show(0);
    }
    for (let button of this.mouth) {
      button.show(vol);
    }

    fill(255, 140, 0);
    let nw = this.r * 0.5;
    let nh = this.r * 0.1;
    triangle(this.nose.x, this.nose.y,
      this.nose.x, this.nose.y + nh,
      this.nose.x + nw, this.nose.y + nh,
    );

    this.leftArm.show(vol);
    this.rightArm.show(vol);
  }
}