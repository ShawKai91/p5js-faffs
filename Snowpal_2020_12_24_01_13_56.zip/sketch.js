const golden = (2 / (1 + Math.sqrt(5)));

let pal;
let mic;

function setup() {
  createCanvas(600, 800);
  pal = new Snowpal(200);
  mic = new p5.AudioIn();
  mic.start();
}

function draw() {
  background(200);
  let vol = mic.getLevel();
  //console.log(vol);
  pal.show(vol);
  
  //noLoop();
}